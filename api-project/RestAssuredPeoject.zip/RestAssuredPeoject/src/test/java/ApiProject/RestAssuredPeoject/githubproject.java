package ApiProject.RestAssuredPeoject;

import org.testng.annotations.BeforeClass;

import static io.restassured.RestAssured.given;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.http.ContentType;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class githubproject {
	
	RequestSpecification requestSpec;
	String sshKey;
	int sshKeyId;
	
	@BeforeClass
	public void setup()
	{
		     requestSpec = new RequestSpecBuilder()
				.setContentType(ContentType.JSON)
				.addHeader("Authorization", "token xxx")
				.setBaseUri("https://api.github.com")
				.build();
		
		sshKey = "ssh-rsa xxx";
		
	}
	
	@Test (priority=1)
	public void postrequest()
	{
		String reqBody ="{\"title\": \"TestKey\", \"key\": \"" + sshKey + "\" }";
		Response response = given().spec(requestSpec)
				.body(reqBody).when().post("/user/keys");
		String resBody = response.getBody().asPrettyString();
		System.out.println(resBody);
		sshKeyId = response.then().extract().path("id");
		response.then().statusCode(201);
		
	}
	
	@Test (priority=2)
	public void getrequest()
	{
		Response response = given().spec(requestSpec)
				.when().get("/user/keys");
		String resBody = response.getBody().asPrettyString();
		System.out.println(resBody);
		
		response.then().statusCode(200);
		
		
	}

	@Test (priority=3)
	public void deleterequest()
	{
		Response response = given().spec(requestSpec)
				.pathParam("KeyId", sshKeyId)
				.when().delete("/user/keys/{KeyId}");
		String resBody = response.getBody().asPrettyString();
		System.out.println(resBody);
		response.then().statusCode(204);
	}
}
