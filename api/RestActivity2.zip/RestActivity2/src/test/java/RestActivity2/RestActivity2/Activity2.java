package RestActivity2.RestActivity2;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class Activity2 {
	
	final static String ROOT_URI = "https://petstore.swagger.io/v2/user";

	  @Test (priority=1)
	  public void addnewuser() throws IOException  
	  
	  {
		  
		  FileInputStream inputJSON = new FileInputStream("src/test/java/user.json");
		  byte[] buffer = new byte[10];
		  StringBuilder sb = new StringBuilder();
		  while(inputJSON.read(buffer) != -1)
		  {
			  sb.append(new String(buffer));
			  buffer = new byte[10];
		  }
		  inputJSON.close();
		  String reqBody = sb.toString();
		  
	      
	      Response res = 
	              given().contentType(ContentType.JSON) 
	              .body(reqBody)
	              .when().post(ROOT_URI);
	   
	          inputJSON.close();
	          res.then().body("code", equalTo(200));
			  
	  }
	  
	  @Test (priority=2)
	  public void getuserinfo() 
	  {
		  File outputJSON = new File("src/test/java/userGETResponse.json");

	      Response response = 
	          given().contentType(ContentType.JSON) 
	          .pathParam("username", "Sangee") 
	          .when().get(ROOT_URI + "/{username}"); 
	      
	      
	      String resBody = response.getBody().asPrettyString();

	      try {
	          
	          outputJSON.createNewFile();
	          
	          FileWriter writer = new FileWriter(outputJSON.getPath());
	          writer.write(resBody);
	          writer.close();
	      } catch (IOException excp) {
	          excp.printStackTrace();
	      }
	      
	      response.then().body("username", equalTo("Sangee"));
	      response.then().body("firstName", equalTo("Sangeetha"));
	      response.then().body("lastName", equalTo("Sumithran"));
	  }
	  
	  @Test (priority=3)
	  public void deleteuserinfo() throws Exception
	  {
		  Response response = 
		            given().contentType(ContentType.JSON) 
		            .pathParam("username", "Sangee")
		            .when().delete(ROOT_URI + "/{username}"); 

		        // Assertion
		        response.then().body("code", equalTo(200));
		        response.then().body("message", equalTo("Sangee")); 
	  }
	}



