package RestAssured.ActivitiesRest;

import org.testng.annotations.Test;

import io.restassured.http.ContentType;
import io.restassured.response.Response;


import static org.hamcrest.CoreMatchers.equalTo;
import static io.restassured.RestAssured.*;

public class Activity1 {
	
	final static String ROOT_URI = "https://petstore.swagger.io/v2/pet";
	
  @Test (priority=1)
  public void postPet()
  {
	  String reqbody = "{"
	            + "\"id\": 90612,"
	            + "\"name\": \"Jill\","
	            + " \"status\": \"alive\""
	        + "}"; 
	  
	  Response res = 
	            given().contentType(ContentType.JSON) // Set headers
	            .body(reqbody) // Add request body
	            .when().post(ROOT_URI); 
	  
	 //res.then().body("id", equalTo(90612));
	 res.then().body("name", equalTo("Jill"));
	 res.then().body("status", equalTo("alive"));
	 
  }
  
  @Test (priority=2)
  public void getPet()
  {
	  Response res = 
	            given().contentType(ContentType.JSON) 
	            .when().pathParam("petId", "90612") 
	            .get(ROOT_URI + "/{petId}");
	 
	       
	        //res.then().body("id", equalTo("<90612>"));
	        res.then().body("name", equalTo("Jill"));
	        res.then().body("status", equalTo("alive"));  
  }
  
  @Test (priority=3)
  public void deletePet()
  {
	  Response res = 
	            given().contentType(ContentType.JSON) 
	            .when().pathParam("petId", "90612") 
	            .delete(ROOT_URI + "/{petId}"); 
	  
	 res.then().body("code", equalTo(200));
     //res.then().body("message", equalTo("<90612>"));
  }
  
}
